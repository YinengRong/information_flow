# -*- coding: utf-8 -*-
"""
Created on Mon Sep  7 16:26:22 2020

@author: easycan @   yinengrong@foxmail.com
causality_est_v1.1
updates: 
    v1.2  20210709
    add multi_est_Xn in causality_calculate
    add est_panel in causality_calculate
    add est_panel_Xn in causality_calculate
    v1.1  20201125
    add more input cases
    add a version with less warning sentences (causality_calculate)
    v1.0  20200907
    rewrite from causality_est.m tau_est.m multi_causality_est.m 

********************************************************************************************************************
function [T21, err90, err95, err99] = causality_est(x1, x2, np)

Estimate T21, the information transfer from series X2 to series X1 
dt is taken to be 1.

On input:
     X1, X2: the series (n by 1 colum vectors)
     np: integer >=1, time advance in performing Euler forward 
	 differencing, e.g., 1, 2. Unless the series are generated
	 with a highly chaotic deterministic system, np=1 should be
	 used. 

On output:
   T21:  info flow from X2 to X1	(Note: Not X1 -> X2!)
   err90: standard error at 90% significance level
   err95: standard error at 95% significance level
   err99: standard error at 99% significance level

********************************************************************************************************************
[tau21, dH1_star, dH1_noise] = tau_est(xx1, xx2, np)

Estimate tau21, the normalized information transfer from X2 to X1 
On input:
   X1, X2: the series
   np: integer >=1, time advance in performing Euler forward 
   differencing, e.g., 1, 2. Unless the series are generated
   with a highly chaotic deterministic system, np=1 should be
   used.
On output:
   tau21:  relative info flow from X2 to X1	(Note: Not X1 -> X2!)
   dH1_star:  relative contribution from X1 to itself
		(Lyapunov exponent)
   dH1_noise: relative noise contribution
		(noise-to-signal ratio)
********************************************************************************************************************
function [T21, err90, err95, err99] = multi_causality_est(x, np)

Estimate T21, the information transfer from series X2 to series X1, among
M time series (stored as column vectors in X).
dt is taken to be 1.
On input:
    XX: matrix storing the M time series (each as Nx1 column vectors)
       X1 and X2 stored as the first two column vectors
    np: integer >=1, time advance in performing Euler forward 
	 differencing, e.g., 1, 2. Unless the series are generated
	 with a highly chaotic deterministic system, np=1 should be
	 used. 

 On output:
    T21:  info flow from X2 to X1	(Note: Not X1 -> X2!)
    err90: standard error at 90% significance level
    err95: standard error at 95% significance level
    err99: standard error at 99% significance level
*******************************************************************************************************************
Citations: 
    X. San Liang, 2014: Unraveling the cause-effect relation between time series. Phys. Rev. E 90, 052150.
    X. San Liang, 2015: Normalizing the causality between time series. Phys. Rev. E 92, 022126.
    X. San Liang, 2016: Information flow and causality as rigorous notions ab initio. Phys. Rev. E, 94, 052201.
    X. San Liang, 2021: Normalized Multivariate Time Series Causality Analysis and Causal Graph Reconstruction. Entropy. 23. 679.
    

"""

import numpy as npy
import warnings
import time
warnings.filterwarnings('ignore')  #ignore warning error,such as: RuntimeWarning: invalid value encountered in subtract

class causality:
    def __init__(self,xx1=[],xx2=[],xx=[],np=1,t=[]):
        self.xx1=xx1
        self.xx2=xx2
        self.xx=xx
        self.np=np
        self.t=t
    def est(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            print(npy.array(xx1.shape).shape)
            return  print('multi series of x1 or x2, please use multi_est instead!')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        # print(nm)
        dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x1  = xx1[0:nm-np];
        dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x2  = xx2[0:nm-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        invNI = npy.linalg.inv(NI);
        var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        return T21,err90,err95,err99
    def tau(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            return print('multi series of x1 or x2, please use multi_est instead! ')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        # print(nm)
        dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x1  = xx1[0:nm-np];
        dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x2  = xx2[0:nm-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        # invNI = npy.linalg.inv(NI);
        # var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        # var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        # z99 = 2.56;
        # z95 = 1.96;
        # z90 = 1.65;
        # err90 = npy.sqrt(var_T21) * z90;
        # err95 = npy.sqrt(var_T21) * z95;
        # err99 = npy.sqrt(var_T21) * z99;
        
        dH1_star = a11;
        dH1_noise = b1**2/(2*C[0,0]);
        Z=abs(T21)+abs(dH1_noise)+abs(dH1_star)
        
        tau21 = T21/Z;dH1_star=dH1_star/Z;dH1_noise = dH1_noise/Z;
        
        return tau21, dH1_star, dH1_noise
    def multi_est(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = cau.est()
                print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        dx1 = (xx[np:nm,0]- xx[0:nm-np,0] )/(np*dt)
        x = xx[0:nm-np, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)
        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            print ('x1==x2, please check the data')
        
            
        a12 = aln[1,0];
                
        T21 = C[0,1]/C[0,0] * a12;
        
        
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        
        var_a12 = invNI[2,2]; 
        var_T21 = (C[0,1]/C[0,0])**2 * var_a12;
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        
        return T21,err90,err95,err99
    
    
    def multi_est_Xn(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = cau.est()
                print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        dx1 = (xx[np:nm,0]- xx[0:nm-np,0] )/(np*dt)
        x = xx[0:nm-np, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)

        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            print ('x1==x2, please check the data')
        
            
        # a12 = aln[1,0];
                
        # T21 = C[0,1]/C[0,0] * a12;
        T21=npy.zeros([1,M])
        T21[0,0] =npy.nan;
        for k in range(1,M):
             T21[0,k] = C[0,k]/C[0,0] * aln[k,0];
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        # var_a12 = invNI[2,2]; 
        var_a12=npy.ones([1,M+1])
        for k in range(M):
            var_a12[0,k] = invNI[k+1,k+1];
        
        var_T21 = (C[0,1]/C[0,0])**2 * var_a12[0,0:M];
        
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        
        return T21,err90,err95,err99
    
    
class causality_calculate:
    #same as above, with no warning sentences
    def __init__(self,xx1=[],xx2=[],xx=[],t=[],np=1):
        self.xx1=xx1
        self.xx2=xx2
        self.xx=xx
        self.np=np
        self.t=t
    def est(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            print(npy.array(xx1.shape).shape)
            return  0#print('multi series of x1 or x2, please use multi_est instead!')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        # print(nm)
        dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x1  = xx1[0:nm-np];
        dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x2  = xx2[0:nm-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        invNI = npy.linalg.inv(NI);
        var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        z80 = 1.28;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        return T21,err90,err95,err99
    def tau(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            return 0#print('multi series of x1 or x2, please use multi_est instead! ')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        # print(nm)
        dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x1  = xx1[0:nm-np];
        dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        x2  = xx2[0:nm-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        # invNI = npy.linalg.inv(NI);
        # var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        # var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        # z99 = 2.56;
        # z95 = 1.96;
        # z90 = 1.65;
        # err90 = npy.sqrt(var_T21) * z90;
        # err95 = npy.sqrt(var_T21) * z95;
        # err99 = npy.sqrt(var_T21) * z99;
        
        dH1_star = a11;
        dH1_noise = b1**2/(2*C[0,0]);
        Z=abs(T21)+abs(dH1_noise)+abs(dH1_star)
        
        tau21 = T21/Z;dH1_star=dH1_star/Z;dH1_noise = dH1_noise/Z;
        
        return tau21, dH1_star, dH1_noise
    def multi_est(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    #print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    #print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    #print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    #print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    #print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    #print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    #print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    #print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = causality_calculate.est()
                #print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        dx1 = (xx[np:nm,0]- xx[0:nm-np,0] )/(np*dt)
        x = xx[0:nm-np, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)
        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            #print ('x1==x2, please check the data')
        
            
        a12 = aln[1,0];
                
        T21 = C[0,1]/C[0,0] * a12;
        
        
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        
        var_a12 = invNI[2,2]; 
        var_T21 = (C[0,1]/C[0,0])**2 * var_a12;
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        
        return T21,err90,err95,err99
    def multi_est_Xn(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    # print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    # print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    # print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    # print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    # print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    # print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    # print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    # print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    # print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    # print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    # print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    # print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    # print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                # print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = causality_calculate.est()
                print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                # print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                # print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            # print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            # print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        dx1 = (xx[np:nm,0]- xx[0:nm-np,0] )/(np*dt)
        x = xx[0:nm-np, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)

        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            # print ('x1==x2, please check the data')
        
            
        # a12 = aln[1,0];
                
        # T21 = C[0,1]/C[0,0] * a12;
        T21=npy.zeros([1,M])
        T21[0,0] =npy.nan;
        for k in range(1,M):
             T21[0,k] = C[0,k]/C[0,0] * aln[k,0];
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        # var_a12 = invNI[2,2]; 
        var_a12=npy.ones([1,M+1])
        for k in range(M):
            var_a12[0,k] = invNI[k+1,k+1];
        
        var_T21 = (C[0,0:M]/C[0,0])**2 * var_a12[0,0:M];
        
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        
        return T21,err90,err95,err99
    def est_panel(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        t=self.t
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            print(npy.array(xx1.shape).shape)
            return  0#print('multi series of x1 or x2, please use multi_est instead!')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        j=0;
        tmp=npy.zeros(nm)
        for i in range(1,nm):
            if t[i]-t[i-np]==dt:
                tmp[j]=i;j=j+1;
        ind=(tmp[0:j+1]).astype(npy.int);
        del tmp
        # print(nm)
        #dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        dx1 = (xx1[ind]- xx1[ind-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        # x1  = xx1[0:nm-np];
        x1  = xx1[ind-np];
        # dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        dx2 = (xx2[ind]- xx2[ind-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        # x2  = xx2[0:nm-np];
        x2  = xx2[ind-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        invNI = npy.linalg.inv(NI);
        var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        return T21,err90,err95,err99
    def tau_panel(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        t=self.t
        if npy.array(npy.array(xx1.shape).shape)!=1 or npy.array(npy.array(xx2.shape).shape)!=1:
            return 0#print('multi series of x1 or x2, please use multi_est instead! ')   #输入多条序列
        np=self.np
        nm = npy.shape(xx1)
        nm=nm[0]
        j=0;
        tmp=npy.zeros(nm)
        for i in range(1,nm):
            if t[i]-t[i-np]==dt:
                tmp[j]=i;j=j+1;
        ind=(tmp[0:j+1]).astype(npy.int);
        del tmp
        # print(nm)
        #dx1 = (xx1[np:nm]- xx1[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        dx1 = (xx1[ind]- xx1[ind-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        # x1  = xx1[0:nm-np];
        x1  = xx1[ind-np];
        # dx2 = (xx2[np:nm]- xx2[0:nm-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        dx2 = (xx2[ind]- xx2[ind-np] )/(np*dt)  #  (xx1(1+np:nm, 1) - xx1(1:nm-np, 1)) / (np*dt);
        # x2  = xx2[0:nm-np];
        x2  = xx2[ind-np];
        N=nm-np
        C = npy.cov(x1, x2);
        dC = npy.zeros([2,2])
        dC[0,0] = sum((x1 - npy.mean(x1)) * (dx1 - npy.mean(dx1))); 
        dC[0,1] = sum((x1 - npy.mean(x1)) * (dx2 - npy.mean(dx2))); 
        dC[1,0] = sum((x2 - npy.mean(x2)) * (dx1 - npy.mean(dx1)));
        dC[1,1] = sum((x2 - npy.mean(x2)) * (dx2 - npy.mean(dx2)));
        dC = dC/(N-1);
        C_infty = C;
        detc = npy.linalg.det(C);
        a11 = C[1,1]*dC[0,0] - C[0,1]*dC[1,0]
        a12 = -C[0,1]*dC[0,0] + C[0,0]*dC[1,0]
        a11 = a11/detc
        a12 = a12/detc
        f1 = npy.mean(dx1) - a11 * npy.mean(x1) - a12 * npy.mean(x2);
        R1 = dx1 - (f1 + a11*x1 + a12*x2);
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);
        NI = npy.zeros([4,4])
        NI[0,0] = N * dt / b1/b1;
        NI[1,1] = dt/b1/b1 * sum(x1 * x1);
        NI[2,2] = dt/b1/b1 * sum(x2 * x2);
        NI[3,3] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        NI[0,1] = dt/b1/b1 * sum(x1);
        NI[0,2] = dt/b1/b1 * sum(x2);
        NI[0,3] = 2*dt/b1**3 * sum(R1);
        NI[1,2] = dt/b1/b1 * sum(x1 * x2);
        NI[1,3] = 2*dt/b1**3 * sum(R1 * x1);
        NI[2,3] = 2*dt/b1**3 * sum(R1 * x2);
        NI[1,0] = NI[0,1];
        NI[2,0] = NI[0,2];    NI[2,1] = NI[1,2];
        NI[3,0] = NI[0,3];    NI[3,1] = NI[1,3];   NI[3,2] = NI[2,3];
        # invNI = npy.linalg.inv(NI);
        # var_a12 = invNI[2,2];
        T21 = C_infty[0,1]/C_infty[0,0] * (-C[1,0]*dC[0,0] + C[0,0]*dC[1,0]) / detc;
        # var_T21 = (C_infty[0,1]/C_infty[0,0])**2 * var_a12;
        # z99 = 2.56;
        # z95 = 1.96;
        # z90 = 1.65;
        # err90 = npy.sqrt(var_T21) * z90;
        # err95 = npy.sqrt(var_T21) * z95;
        # err99 = npy.sqrt(var_T21) * z99;
        
        dH1_star = a11;
        dH1_noise = b1**2/(2*C[0,0]);
        Z=abs(T21)+abs(dH1_noise)+abs(dH1_star)
        
        tau21 = T21/Z;dH1_star=dH1_star/Z;dH1_noise = dH1_noise/Z;
        
        return tau21, dH1_star, dH1_noise
    def multi_est_panel(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        t=self.t
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    #print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    #print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    #print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    #print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    #print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    #print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    #print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    #print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = causality_calculate.est_panel()
                #print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        j=0;
        tmp=npy.zeros(nm)
        for i in range(1,nm):
            if t[i]-t[i-np]==dt:
                tmp[j]=i;j=j+1;
        ind=(tmp[0:j+1]).astype(npy.int);
        
        dx1 = (xx[ind,0]- xx[ind-1,0] )/(np*dt)
        x = xx[ind-1, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)
        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            #print ('x1==x2, please check the data')
        
            
        a12 = aln[1,0];
                
        T21 = C[0,1]/C[0,0] * a12;
        
        
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        
        var_a12 = invNI[2,2]; 
        var_T21 = (C[0,1]/C[0,0])**2 * var_a12;
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        return T21,err90,err95,err99
    def multi_est_panel_Xn(self):
        dt = 1;	
        xx1=self.xx1
        xx2=self.xx2
        t=self.t
        xx=self.xx
        np=self.np
        if len(xx)!=0:
            if len(xx1)==0:
                if len(xx2)==0:
                    xx=xx;
                    #print('xx[:,0] is x1, xx[:,1] is x2, xx[:,2:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2;xx[:,2:]=tmp[:,1:]
                    #print('xx[:,0] is x1, xx2 is x2, xx[:,1:] is other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=tmp[:,0];xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];xx[:,N[1]+1:]=xx2[:,1:];
                    #print('xx[:,0] is x1, xx2[:,0] is x2, xx2[:,1:] and xx[:,1:] are other factors')
            elif len(xx1.shape)==1:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+1]);
                    xx[:,0]=xx1;xx[:,1:]=xx
                    #print('xx1 is x1, xx[:,0] is x2, xx[:,1:] is other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;
                    xx=npy.zeros([N[0],N[1]+2]);
                    xx[:,0]=xx1;xx[:,1]=xx2;xx[:,2:]=tmp
                    #print('xx1 is x1, xx2 is x2, xx is other factors')
                else:
                    tmp=xx;N=tmp.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+1+N2[1]]);
                    xx[:,0]=xx1;
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx2[:,1:];
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] and xx are other factors')
            elif len(xx1.shape)==2:
                if len(xx2)==0:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=tmp[:,0];
                    xx[:,2:N[1]+1]=tmp[:,1:];
                    xx[:,N[1]+1:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx[:,0] is x2, xx1[:,1:] and xx[:,1:] are other factors')
                elif len(xx2.shape)==1:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;
                    xx=npy.zeros([N[0],N[1]+1+N1[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2;
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:]=xx1[:,1:];
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] and xx are other factors')
                else:
                    tmp=xx;N=tmp.shape;N1=xx1.shape;N2=xx2.shape;
                    xx=npy.zeros([N[0],N[1]+N1[1]+N2[1]]);
                    xx[:,0]=xx1[:,0];
                    xx[:,1]=xx2[:,0];
                    xx[:,2:N[1]+2]=tmp;
                    xx[:,N[1]+2:N[1]+N1[1]+1]=xx1[:,1:];
                    xx[:,N[1]+N1[1]+1:]=xx2[:,1:];
                    #print('xx1[:,0] is x1, xx2[:,0] is x2, xx1[:,1:] xx2[:,1:] and xx are other factors')
                    
        
        else:
            if len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==1:
                if len(xx2)!=0:
                    N=npy.array(xx1.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1[:,0];xx[:,1]=xx2;xx[:,2:]=xx1[:,1:]
                    #print('xx1[:,0] is x1, xx2 is x2, xx1[:,1:] is other factors')
                else:
                    xx=xx1;
                    #print('xx1[:,0] is x1, xx1[:,1] is x2, xx1[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==2:
                if len(xx1)!=0:
                    N=npy.array(xx2.shape)
                    xx=npy.zeros([N[0],N[1]+1])
                    xx[:,0]=xx1;xx[:,1:]=xx2;
                    #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
                else:
                    xx=xx2;
                    #print('xx2[:,0] is x1, xx2[:,1] is x2, xx2[:,2:] is other factors')
            elif len(npy.array(xx1).shape)==2 and len(npy.array(xx2).shape)==2 :
                N1=npy.array(xx1.shape)
                N2=npy.array(xx2.shape)
                N=N1;N[1]=N2[1]+N1[1];
                xx=npy.zeros([N[0],N[1]])
                xx[:,0]=xx1[:,0];xx[:,1]=xx2[:,0];xx[:,2:N1[1]+2]=xx1[:,1:];xx[:,N1[1]+3:]=xx2[:,1:];
                #print('xx1 is x1, xx2[:,0] is x2, xx2[:,1:] is other factors')
            elif len(npy.array(xx1).shape)==1 and len(npy.array(xx2).shape)==1 and len(xx1)!=0 and len(xx2)!=0:
                T21,err90,err95,err99 = causality_calculate.est_panel()
                #print('please use est() in the next time')
                return T21,err90,err95,err99
            else:
                #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
                #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
                return 0
        if  npy.array(npy.array(xx.shape).shape)!=2:
            #print('multi_est need inputs like: if with x1,x2:  [ x1[:,] x2[:,m] ], [ x1[:,m] x2[:,] ], [ x1[:,m] x2[:,n] ], [ x1[:,] x2[:,] ]')
            #print(' if with x only: x[:,0]->x1 x[:,1]->x2 x[:,1:]->others ')
            return 0
        N=npy.array(xx.shape)
        nm = N[0]; M = N[1];
        j=0;
        tmp=npy.zeros(nm)
        for i in range(1,nm):
            if t[i]-t[i-np]==dt:
                tmp[j]=i;j=j+1;
        ind=(tmp[0:j+1]).astype(npy.int);
        
        dx1 = (xx[ind,0]- xx[ind-1,0] )/(np*dt)
        x = xx[ind-1, :];
        del xx
        N = nm-np;
        C=npy.cov(x.transpose());  #
        dC=npy.zeros([M,1])
        for k in range(M):
            dC[k,0] = sum((x[:,k] - npy.mean(x[:,k])) * (dx1 - npy.mean(dx1))); 
        dC=dC/(N-1)
        try: 
            aln = npy.dot(npy.linalg.inv(C),dC)
        except:
            aln = npy.ones(shape=npy.shape(dC))*float('inf')
            #print ('x1==x2, please check the data')
        
            
        # a12 = aln[1,0];
                
        # T21 = C[0,1]/C[0,0] * a12;
        T21=npy.zeros([1,M])
        T21[0,0] =npy.nan;
        for k in range(1,M):
             T21[0,k] = C[0,k]/C[0,0] * aln[k,0];
        f1 = npy.mean(dx1);
        for k in range(M):
            #f1 = f1 - aln[k,0] * npy.mean(x[:,k]);
            tmp = aln[k,0] * npy.mean(x[:,k]);
            if f1 !=float('inf'):
                f1 = f1 - tmp;
            
        R1 = dx1 - f1;
        for k in range(M):
            #R1 = R1 - aln[k,0] * x[:,k];
            tmp = aln[k,0] * x[:,k];
            if f1 !=float('inf'):
                R1 = R1 - tmp;
        Q1 = sum(R1 * R1);
        b1 = npy.sqrt(Q1 * dt / N);

# covariance matrix of the estimator of (f1, a11, a12,..., a1M, b1)
        NI=npy.zeros([M+2,M+2])
        NI[0,0] = N * dt / b1/b1;
        NI[M+1,M+1] = 3*dt/b1**4 * sum(R1 * R1) - N/b1/b1;
        for k in range(M):
            NI[0,k+1] = dt/b1/b1 * sum(x[:,k]);
        
        NI[0,M+1] = 2*dt/b1**3 * sum(R1);
        
        for k in range(M):
            for j in range(M):
                NI[j+1,k+1] = dt/b1/b1 * sum(x[:,j] * x[:,k]);
        for k in range(M):
            NI[k+1,M+1] = 2*dt/b1**3 * sum(R1 * x[:,k]);
            
        for j in range(M+1):
            for k in range(j):
                NI[j,k]=NI[k,j];
        
        try: 
            invNI = npy.linalg.inv(NI);
        except:
            invNI = npy.ones(shape=npy.shape(NI))*float('inf')
            
        # var_a12 = invNI[2,2]; 
        var_a12=npy.ones([1,M+1])
        for k in range(M):
            var_a12[0,k] = invNI[k+1,k+1];
        
        var_T21 = (C[0,0:M]/C[0,0])**2 * var_a12[0,0:M];
        
        
        z99 = 2.56;
        z95 = 1.96;
        z90 = 1.65;
        err90 = npy.sqrt(var_T21) * z90;
        err95 = npy.sqrt(var_T21) * z95;
        err99 = npy.sqrt(var_T21) * z99;
        
        return T21,err90,err95,err99

if __name__ == '__main__':
    #case 1: for x1 and x2
    print('case 1:')
    a11=0.3;a12=0.1;a22=0.7;a21=0;b1=0.4;b2=0.5;
    x=npy.zeros([1000,])
    y=npy.zeros([1000,])
    x[0]=0.4;y[0]=0.3;
    for i in range(1000-1):
        x[i+1]=a11*x[i]+a21*y[i]+b1*npy.random.normal();
        y[i+1]=a12*x[i]+a22*y[i]+b2*npy.random.normal();
    # x=npy.array([1,2,3,4.3,5.2,6.1,7.3])
    # y=x*2
    # y[1]=y[1]*1.01
    # y[2]=y[2]*0.99
    
    print ("x(i+1)=%.2f * x(i) + %.2f * y(i) + %.2f W" % (a11, a21,b1))
    print ("y(i+1)=%.2f * x(i) + %.2f * y(i) + %.2f W" % (a12, a22,b2))
    cau=causality(y[200:],x[200:])
    T21,_,_,e99 = cau.est()
    tau21,_,_  = cau.tau()
    print()
    if abs(T21)>e99:
        print('x -> y')
        print('percent:%5.2f' % (tau21*100)+'%')
    else:
        print('x not -> y')

    cau=causality(x[200:],y[200:])
    T21,_,_,e99 = cau.est()
    tau21,_,_  = cau.tau()

    if abs(T21)>e99:
        print('y -> x')
        print('precent:%5.2f' % (tau21*100)+'%')
    else:
        print('y not -> x')
        
    #case 2: for x1 ,x2, x3, x4  =>multi 
    print('case 2(test multicausality):')
    a11=0.3;a21=0;  a31=0;  a41=0;  b1=0.4;
    a12=0.5;a22=0.7;a32=0.1;a42=0;  b2=0.5;
    a13=0;  a23=0.3;a33=0.5;a43=0;  b3=0.6;
    a14=0.2;a24=0.4;a34=0.3;a44=0;  b4=0.3;
    xx=npy.zeros([1001,4])
    xx[0]=npy.array([0.4,0.5,0.6,0.7])
    for i in range(1000):
        xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.normal();
        xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.normal();
        xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.normal();
        xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.normal();
    

    print ("x1(i+1)=%.2f * x1(i) + %.2f * x2(i)+%.2f * x3(i) + %.2f * x4(i) + %.2f W" % (a11, a21, a31,a41,b1))
    print ("x2(i+1)=%.2f * x1(i) + %.2f * x2(i)+%.2f * x3(i) + %.2f * x4(i) + %.2f W" % (a12, a22, a32,a42,b2))
    print ("x3(i+1)=%.2f * x1(i) + %.2f * x2(i)+%.2f * x3(i) + %.2f * x4(i) + %.2f W" % (a13, a23, a33,a43,b3))
    print ("x4(i+1)=%.2f * x1(i) + %.2f * x2(i)+%.2f * x3(i) + %.2f * x4(i) + %.2f W" % (a14, a24, a34,a44,b4))
    
    Nxx=npy.array(npy.shape(xx));
    IF=npy.zeros([Nxx[1],Nxx[1]]);
    t21=npy.zeros([Nxx[1],Nxx[1]]);
    err=npy.zeros([Nxx[1],Nxx[1]]);
    a=npy.linspace(0,3,4);a=npy.array(a,int)
    Nxx=npy.array(npy.shape(xx));
    # Nxx[1]=Nxx[1]+1;
    for i in range(4):
        for j in range(4):
            xx12=npy.zeros(Nxx);
            tmp1=xx[:,i];tmp2=xx[:,j];            
            if i==j:
                T21=npy.NaN;
                e99=npy.NaN;
                # tmp3=xx[:,npy.where(a!=i)];
                # xx12[:,2:]=tmp3.squeeze();
            else:
                tmp3=xx[:,npy.where((a!=i)*(a!=j))]
                xx12[:,2:Nxx[1]]=tmp3.squeeze();
                xx12=xx12[:,:Nxx[1]];
                xx12[:,0]=tmp1;xx12[:,1]=tmp2;
                cau2=causality_calculate(xx=xx12)
                T21,_,_,e99 = cau2.multi_est()
            if abs(T21)>e99:
                print('%d -> %d' % (j+1,i+1))
                IF[i,j]=1;
            else:
                if i!=j:
                    print('%d not -> %d' % (j+1,i+1))
            t21[i,j]=T21;
            err[i,j]=e99;
    print('xj -> xi:')
    f='    j';
    Nxx=npy.array(npy.shape(xx));
    for i in range(Nxx[1]):
        f='    '+f;
    print(f)
    f='    %6d'%1;
    for i in range(Nxx[1]-1):
        f=f+'%5d'%(i+2);
    print(f)
    for j in range(Nxx[1]):
        if j== npy.floor(Nxx[1]/2):
            f=' i';
        else:
            f='  ';
        f=f+'%5d'%(j+1)
        for i in range(Nxx[1]):
            f=f+'  %d  ' %(IF[j,i])
        print(f)
    
    print('Tj->i:')
    f='    j';
    Nxx=npy.array(npy.shape(xx));
    for i in range(Nxx[1]):
        f='     '+f;
    print(f)
    f='        %7d'%1;
    for i in range(Nxx[1]-1):
        f=f+'%9d'%(i+2);
    print(f)
    for j in range(Nxx[1]):
        if j== npy.floor(Nxx[1]/2):
            f=' i';
        else:
            f='  ';
        f=f+'%5d'%(j+1)
        for i in range(Nxx[1]):
            f=f+' %8.4f ' %(t21[j,i])
        print(f)
        
    print('e99:')
    f='    j';
    Nxx=npy.array(npy.shape(xx));
    for i in range(Nxx[1]):
        f='     '+f;
    print(f)
    f='        %7d'%1;
    for i in range(Nxx[1]-1):
        f=f+'%9d'%(i+2);
    print(f)
    for j in range(Nxx[1]):
        if j== npy.floor(Nxx[1]/2):
            f=' i';
        else:
            f='  ';
        f=f+'%5d'%(j+1)
        for i in range(Nxx[1]):
            f=f+' %8.4f ' %(err[j,i])
        print(f)
    
    i=1;
    j=0;t21=t21*1e4;err=err*1e4;
    print('for multi_est:')
    print('Tn->%d(10e-4): %6.2f %6.2f %6.2f %6.2f'%(i,t21[i,0], t21[i,1], t21[i,2], t21[i,3]))
    print('err99(10e-4): %6.2f %6.2f %6.2f %6.2f'%(err[i,0], err[i,1], err[i,2], err[i,3]))
    print('for multi_est_Xn:')
    print('x1-x4->x%d'%(i+1))
    xx12=npy.zeros([Nxx[0],Nxx[1]]);
    xx12[:,2:4]=xx[:,2:4];
    xx12[:,0]=xx[:,i].squeeze();xx12[:,1]=xx[:,j].squeeze();
    cau2=causality_calculate(xx=xx12)
    T21,_,_,e99 = cau2.multi_est_Xn()
    T21=T21.squeeze()*1e4;
    e99=e99*1e4;
    tmp=npy.array(T21);
    T21[j]=tmp[i];T21[i]=tmp[j];
    tmp=npy.array(e99);
    e99[j]=tmp[i];e99[i]=tmp[j];
    print('Tn->%d(10e-4): %6.2f %6.2f %6.2f %6.2f'%(i,T21[0], T21[1], T21[2], T21[3]))
    print('err99(10e-4): %6.2f %6.2f %6.2f %6.2f'%(e99[0], e99[1], e99[2], e99[3]))



    #case 3: for x1 ,x2, x3, x4  =>panel data
    print('case 3(panel data):')
    a11=0.3;a21=0;  a31=0;  a41=0;  b1=0.4;
    a12=0.5;a22=0.7;a32=0.1;a42=0;  b2=0.5;
    a13=0;  a23=0.3;a33=0.5;a43=0;  b3=0.6;
    a14=0.2;a24=0.4;a34=0.3;a44=0;  b4=0.3;
    case_num=1000;
    xx=npy.zeros([case_num,1001,4])
    xx[:,0,:]=npy.array([0.4,0.5,0.6,0.7])
    print('----------generating the data----------')
    for icase in range(case_num):
        if icase!=0:
            xx[icase,0,:]=xx[icase,0,:]*npy.random.normal(0,0,4)
        if npy.ceil(icase/20)*20==icase:
            print(icase)
        for i in range(1000):
            xx[icase,i+1,0]=a11*xx[icase,i,0]+a21*xx[icase,i,1]+a31*xx[icase,i,2]+a41*xx[icase,i,3]+b1*npy.random.normal();
            xx[icase,i+1,1]=a12*xx[icase,i,0]+a22*xx[icase,i,1]+a32*xx[icase,i,2]+a42*xx[icase,i,3]+b2*npy.random.normal();
            xx[icase,i+1,2]=a13*xx[icase,i,0]+a23*xx[icase,i,1]+a33*xx[icase,i,2]+a43*xx[icase,i,3]+b3*npy.random.normal();
            xx[icase,i+1,3]=a14*xx[icase,i,0]+a24*xx[icase,i,1]+a34*xx[icase,i,2]+a44*xx[icase,i,3]+b4*npy.random.normal();

    X = npy.zeros([1000,4]);
    t = npy.zeros([1000,]);
    for j in range(100):
        i=int(npy.floor(npy.random.uniform()*1000));
        X[10*j:10*(j+1),:]=xx[i,-10:,:];
        # t[10*j:10*(j+1),:]=npy.tile(npy.linspace(0,9,10),(4,1)).T;
        t[10*j:10*(j+1),]=npy.linspace(0,9,10);
    print('start calculate:')
    time_start=time.time()
    cau2=causality_calculate(xx1=X[:,0],xx2=X[:,1],t=t)
    T21,_,_,e99=cau2.est_panel()
    time_end=time.time()
    print('est_panel: T2->1: %8.4f e90: %8.4f'%(T21, e99))
    print('time cost: %8.4f s'%(time_end-time_start))
    
    cau2=causality_calculate(xx=X,t=t)
    T21,_,_,e99=cau2.multi_est_panel()
    print('multi_est_panel: T2->1: %8.4f e90: %8.4f'%(T21, e99))
    T21,_,_,e99=cau2.multi_est_panel_Xn()
    T21=T21.squeeze()
    print('multi_est_panel_Xn: Tn->1:')
    print('%8.4f %8.4f %8.4f %8.4f'%(T21[0], T21[1], T21[2], T21[3]))
    print('multi_est_panel_Xn: e99:')
    print('%8.4f %8.4f %8.4f %8.4f'%(e99[0], e99[1], e99[2], e99[3]))


    print('')    
    print('')    
    print('')    
    cau2=causality_calculate(xx1=X[:,1],xx2=X[:,0],t=t)
    T12,_,_,e99=cau2.est_panel()
    
    print('est_panel: T1->2: %8.4f e99: %8.4f'%(T12, e99))
    
    cau2=causality_calculate(xx1=X[:,1],xx2=X[:,0],xx=X[:,2:],t=t)
    T12,_,_,e99=cau2.multi_est_panel()
    print('multi_est_panel: T1->2: %8.4f e99: %8.4f'%(T12, e99))
    j=0;i=1;
    xx12=0*X;
    xx12[:,2:4]=X[:,2:];
    xx12[:,0]=X[:,i].squeeze();xx12[:,1]=X[:,j].squeeze();
    T21,_,_,e99=cau2.multi_est_panel_Xn()
    T21=T21.squeeze()
    T21=T21.squeeze();
    e99=e99;
    tmp=npy.array(T21);
    T21[j]=tmp[i];T21[i]=tmp[j];
    tmp=npy.array(e99);
    e99[j]=tmp[i];e99[i]=tmp[j];
    print('multi_est_panel_Xn: Tn->2:')
    print('%8.4f %8.4f %8.4f %8.4f'%(T21[0], T21[1], T21[2], T21[3]))
    print('multi_est_panel_Xn: e99:')
    print('%8.4f %8.4f %8.4f %8.4f'%(e99[0], e99[1], e99[2], e99[3]))