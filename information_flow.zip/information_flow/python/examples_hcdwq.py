# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 14:44:41 2020

@author: easycan    @   yinengrong@foxmail.com
         mingmingbi @   bimingm@foxmail.com (data provider)
input:  causality(xx1,xx2,xx,np)
two kinds:  
    1. xx1 and xx2
    if the dimensions of xx1 and xx2 equal to 1
        xx1->x1,xx2->x2
    else
       xx1[:,0]->x1
       xx2[:,0]->x2
       remains are other relative factors
    2. xx
    xx[:,0]->x1
    xx[:,1]->x2
    remains are other relative factors

    np =1 or 2
    
outputs:
    causality.est:
        T21,err90,err95,err99
    causality.tau:
        T21,err90,err95,err99
    causality.multi_est:
        T21,err90,err95,err99
        
comprehensive messages are in causality_est and Citations: 
    X. San Liang, 2014: Unraveling the cause-effect relation between time series. Phys. Rev. E 90, 052150.
    X. San Liang, 2015: Normalizing the causality between time series. Phys. Rev. E 92, 022126.
    X. San Liang, 2016: Information flow and causality as rigorous notions ab initio. Phys. Rev. E, 94, 052201.
"""

import numpy as npy
import sys
sys.path.append(r'E:\work\tools\information_flow')  # 加载causality_est.py 文件夹所在位置
from causality_est import causality_calculate as cau  # need numpy， pip install numpy 或 conda install numpy

# more cases are in causality_est.py
import scipy.io as scio
data = scio.loadmat(r'E:\work\tools\information_flow\data\testbi.mat')

x1 = data['x1']
x2 = data['x2']
x2 = x2.astype(npy.float64)  # 降水数据默认导入时为整型16，计算出错，转换为64位才计算正确

T = npy.zeros([160])
e90 = npy.zeros([160])
e95 = npy.zeros([160])
e99 = npy.zeros([160])

for k in range(0, 160):  # 黑潮大弯曲指数对中国160站降水的信息流
    a = cau(x2[:, k], x1[:, 0])
    T[k], e90[k], e95[k], e99[k]=a.est()

print(T[52], e90[52], e95[52], e99[52])  # 52随机设置的，看看与matlab计算是否相同

print('matlab results:')
print(data['T12'][52], data['err90_12'][52], data['err95_12'][52], data['err99_12'][52])

