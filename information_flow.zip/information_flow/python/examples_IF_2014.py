# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 14:44:41 2020

@author: easy @   yinengrong@foxmail.com

input:  causality(xx1,xx2,xx,np)
two kinds:  
    1. xx1 and xx2
    if the dimensions of xx1 and xx2 equal to 1
        xx1->x1,xx2->x2
    else
       xx1[:,0]->x1
       xx2[:,0]->x2
       remains are other relative factors
    2. xx
    xx[:,0]->x1
    xx[:,1]->x2
    remains are other relative factors

    np =1 or 2
    
outputs:
    causality.est:
        T21,err90,err95,err99
    causality.tau:
        T21,err90,err95,err99
    causality.multi_est:
        T21,err90,err95,err99
        
comprehensive messages are in causality_est and Citations: 
1.    X. San Liang, 2014: Unraveling the cause-effect relation between time series. Phys. Rev. E 90, 052150.
2.    X. San Liang, 2015: Normalizing the causality between time series. Phys. Rev. E 92, 022126.
3.    X. San Liang, 2016: Information flow and causality as rigorous notions ab initio. Phys. Rev. E, 94, 052201.
"""




import sys
sys.path.append(r'.\information_flow\python') 
#加载causality_est.py 文件夹所在位置
from causality_est import causality as cau #need numpy， pip install numpy 或 conda install numpy



# Data for Fig. 1a in Liang (2014)
#more cases are in causality_est.py 
import numpy as npy
xx = npy.loadtxt('../data/PRE2014.dat');
dt = xx[1,0]-xx[0,0];
xx=xx[5000-1:100000,:].transpose()
a=cau(xx[1:,:]);
try:
    print('IF')
    T21,e90,e95,e99=a.est()
except:
    print('error')
else:
    print('%.6f  %.6f  %.6f  %.6f'%(T21/dt,e90/dt,e95/dt,e99/dt))

a=cau(xx[1,:],xx[2,]);
try:
    print('IF')
    T21,e90,e95,e99=a.est()
except:
    print('error')
else:
    print('%.6f  %.6f  %.6f  %.6f'%(T21/dt,e90/dt,e95/dt,e99/dt))
