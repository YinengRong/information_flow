# -*- coding: utf-8 -*-
"""
Created on Sat Sep 12 14:44:41 2020

@author: easy @   yinengrong@foxmail.com

input:  causality(xx1,xx2,xx,np)
two kinds:  
    1. xx1 and xx2
    if the dimensions of xx1 and xx2 equal to 1
        xx1->x1,xx2->x2
    else
       xx1[:,0]->x1
       xx2[:,0]->x2
       remains are other relative factors
    2. xx
    xx[:,0]->x1
    xx[:,1]->x2
    remains are other relative factors

    np =1 or 2
    
outputs:
    causality.est:
        T21,err90,err95,err99
    causality.tau:
        T21,err90,err95,err99
    causality.multi_est:
        T21,err90,err95,err99
        
comprehensive messages are in causality_est and Citations: 
    X. San Liang, 2014: Unraveling the cause-effect relation between time series. Phys. Rev. E 90, 052150.
    X. San Liang, 2015: Normalizing the causality between time series. Phys. Rev. E 92, 022126.
    X. San Liang, 2016: Information flow and causality as rigorous notions ab initio. Phys. Rev. E, 94, 052201.
"""




import sys
sys.path.append(r'E:\work\tools\information_flow') 
#加载causality_est.py 文件夹所在位置
from causality_est import causality as cau #need numpy， pip install numpy 或 conda install numpy



#test with Zhang Lanxin's data
#more cases are in causality_est.py 
import scipy.io as scio
data = scio.loadmat(r'E:\work\tools\information_flow\data\test.mat');
xx=data['xx'];
xx=xx.transpose()
a=cau(xx);
try:
    print('IF')
    T21,e90,e95,e99=a.est()
except:
    1+1
else:
    print('%.6f  %.6f  %.6f  %.6f'%(T21,e90,e95,e99))
print('multi IF')
T21,e90,e95,e99=a.multi_est()
print('%.6f  %.6f  %.6f  %.6f'%(T21,e90,e95,e99))

print('matlab results:')
print('%.6f  %.6f  %.6f  %.6f'%(data['result2'],data['err90'],data['err95'],data['err99']))


import numpy as npy
a11=0.3;a21=0;  a31=0;  a41=0;  b1=0.4;
a12=0.5;a22=0.7;a32=0.1;a42=0;  b2=0.5;
a13=0;  a23=0.3;a33=0.5;a43=0;  b3=0.6;
a14=0.2;a24=0.4;a34=0.3;a44=0;  b4=0.3;
xx=npy.zeros([100001,4])
xx[0]=npy.array([0.4,0.5,0.6,0.7])
for i in range(0,20000):
    xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.uniform(-1,1);
    xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.uniform(-1,1);
    xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.uniform(-1,1);
    xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.uniform(-1,1);

a11=0.25;a21=0;  a31=0;  a41=0;  b1=0.4;
a12=0.45;a22=0.7;a32=0.1;a42=0;  b2=0.5;
a13=0;  a23=0;a33=0.5;a43=0;  b3=0.6;
a14=0.0;a24=-0.4;a34=0.3;a44=0;  b4=0.3;
for i in range(20000,40000):
    xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.uniform(-1,1);
    xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.uniform(-1,1);
    xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.uniform(-1,1);
    xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.uniform(-1,1);

a11=0.25;a21=0;  a31=0.3;  a41=0;  b1=0.4;
a12=0.45;a22=0.15;a32=0.4;a42=0.3;  b2=0.5;
a13=0;  a23=-0.3;a33=-0.2;a43=0;  b3=0.6;
a14=0.0;a24=0;a34=0.3;a44=0;  b4=0.3;
for i in range(40000,60000):
    xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.uniform(-1,1);
    xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.uniform(-1,1);
    xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.uniform(-1,1);
    xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.uniform(-1,1);

a11=0.25;a21=0;  a31=0.3;  a41=0;  b1=0.2;
a12=0.45;a22=0.15;a32=0.4;a42=0.3;  b2=0.7;
a13=0;  a23=-0.3;a33=-0.2;a43=0;  b3=0.3;
a14=0.0;a24=0;a34=0.3;a44=0;  b4=0.5;
for i in range(60000,80000):
    xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.uniform(-1,1);
    xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.uniform(-1,1);
    xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.uniform(-1,1);
    xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.uniform(-1,1);

a11=0   ;a21=0.4;  a31=0.2;  a41=-0.34;  b1=0.2;
a12=0.45;a22=0.15;a32=0;a42=0.3;  b2=0.7;
a13=0;   a23=0;a33=-0.2;a43=0;  b3=0.3;
a14=0.0; a24=0;a34=0.3;a44=0;  b4=0.5;
for i in range(80000,100000):
    xx[i+1,0]=a11*xx[i,0]+a21*xx[i,1]+a31*xx[i,2]+a41*xx[i,3]+b1*npy.random.uniform(-1,1);
    xx[i+1,1]=a12*xx[i,0]+a22*xx[i,1]+a32*xx[i,2]+a42*xx[i,3]+b2*npy.random.uniform(-1,1);
    xx[i+1,2]=a13*xx[i,0]+a23*xx[i,1]+a33*xx[i,2]+a43*xx[i,3]+b3*npy.random.uniform(-1,1);
    xx[i+1,3]=a14*xx[i,0]+a24*xx[i,1]+a34*xx[i,2]+a44*xx[i,3]+b4*npy.random.uniform(-1,1);

from causality_est import causality 
Nxx=npy.array(npy.shape(xx));dt=100;
IF=npy.zeros([Nxx[1],Nxx[1],100001]);
for it in range(10000,90000):
    if npy.floor(it/100)*100==it:
        print(it)
    for i in range(4):
        for j in range(4):
            Nxx=npy.array(npy.shape(xx));Nxx[1]=Nxx[1]+1;
            xx12=npy.zeros(Nxx);
            tmp1=xx[:,i];tmp2=xx[:,j];
            a=npy.linspace(0,3,4);a=npy.array(a,int)
            if i==j:
                tmp3=xx[:,npy.where(a!=i)];
                xx12[:,2:]=tmp3.squeeze();
            else:
                tmp3=xx[:,npy.where((a!=i)*(a!=j))]
                xx12[:,2:Nxx[1]-1]=tmp3.squeeze();
                xx12=xx12[:,:Nxx[1]-1];
                
            xx12[:,0]=tmp1;xx12[:,1]=tmp2;
            cau=causality(xx=xx12[it-dt:it+dt,:])
            #T21,_,_,e99 = cau.multi_est()
            if abs(T21)>e99:
                #print('%d -> %d' % (j+1,i+1))
                IF[i,j,it]=T21;
            #else:
                #print('%d not -> %d' % (j+1,i+1))