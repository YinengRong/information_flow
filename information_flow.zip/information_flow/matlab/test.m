clear

x1(1)=0.4;x2(1)=0.5;x3(1)=0.6;x4(1)=0.7;
x5(1)=0.4;x6(1)=0.5;x7(1)=0.6;x8(1)=0.7;
x9(1)=0.4;x10(1)=0.5;
for i=1:10000
    x1(i+1)=0.30 * x1(i) + 0.00 * x2(i)+0.00 * x3(i) + 0.00 * x4(i) + 0.40*randn(1);
    x2(i+1)=0.80 * x1(i) + 0.90 * x2(i)+0.00 * x3(i) + 0.00 * x4(i) + 0.50*randn(1);
    x3(i+1)=0.00 * x1(i) + 0.50 * x2(i)+0.50 * x3(i) + 0.00 * x4(i) + 0.60*randn(1);
    x4(i+1)=0.20 * x1(i) + 0.40 * x2(i)+0.30 * x3(i) + 0.00 * x4(i) + 0.30*randn(1);
    x5(i+1)=0.40 * x1(i) + 0.30 * x2(i)+0.30 * x3(i) + 0.30 * x5(i) + 0.20*randn(1);
    x6(i+1)=0.40 * x1(i) + 0.30 * x2(i)+0.30 * x3(i) + 0.20 * x6(i) + 0.40*randn(1);
    x7(i+1)=0.40 * x1(i) + 0.40 * x2(i)+0.30 * x3(i) + 0.40 * x7(i) + 0.40*randn(1);
    x8(i+1)=0.40 * x1(i) + 0.40 * x2(i)+0.30 * x3(i) + 0.34 * x8(i) + 0.40*randn(1);
    x9(i+1)=0.40 * x1(i) + 0.40 * x2(i)+0.30 * x3(i) + 0.33 * x8(i) + 0.70*randn(1);
    x10(i+1)=0.40 * x1(i) + 0.30 * x2(i)+0.20 * x3(i) + 0.13 * x8(i) + 0.60*randn(1);
end

xx=[x1' x2' x3' x4' x5' x6' x7' x8' x9' x10'];

tic
key=1:10;
for i=1:10
    %for j=1:10
    %    if i~=j
    %        tmp1=xx(:,i);tmp2=xx(:,j);tmp3=xx(:,key~=i&key~=j);
            %tmp1=xM(2:end,i);tmp2=xM(2:end,j);tmp3=xM(2:end,key~=i&key~=j);tmp4=xM(1:end-1,key~=i&key~=j);
            X=xx;%[tmp1,tmp2,tmp3];%,tmp4];
            t21=multi_causality_est_all(X,1);
%             disp([i j])
%         else
%             t21(i,j)=NaN;err(i,j)=NaN;
   %     end
   % end
end

toc

tic
key=1:10;
for i=1:10
    for j=1:10
        if i~=j
            tmp1=xx(:,i);tmp2=xx(:,j);tmp3=xx(:,key~=i&key~=j);
            %tmp1=xM(2:end,i);tmp2=xM(2:end,j);tmp3=xM(2:end,key~=i&key~=j);tmp4=xM(1:end-1,key~=i&key~=j);
            X=[tmp1,tmp2,tmp3];%,tmp4];
            h=gctest(tmp1,tmp2,tmp3);
%             disp([i j])
%         else
            %t21(i,j)=NaN;err(i,j)=NaN;
        end
    end
end
toc