% Make sure that year_month_date.dat exists, or run Year_month_date.x first.
% 
clear

DIR = '../data';
% aapl = load([DIR, '/AAPL.dat']);   	[n1,fo]=size(aapl);
% amazon = load([DIR, '/AMZN.dat']); 	[n2,fo]=size(amazon);
% cvs = load([DIR, '/CVS.dat']);	[n3,fo]=size(cvs);
% ford = load([DIR, '/F.dat']);		[n4,fo]=size(ford);
% ge = load([DIR, '/GE.dat']);		[n5,fo]=size(ge);
% google = load([DIR, '/GOOGL.dat']);	[n6,fo]=size(google);
% ibm = load([DIR, '/IBM.dat']); 	[n7,fo]=size(ibm);
% intc = load([DIR, '/INTC.dat']);	[n8,fo]=size(intc);
% msft = load([DIR, '/MSFT.dat']);	[n9,fo]=size(msft);
% toyota= load([DIR, '/TM.dat']); 	[n10,fo]=size(toyota);
% wmt = load([DIR, '/WMT.dat']);	[n11,fo]=size(wmt);
% xom = load([DIR, '/XOM.dat']);	[n12,fo]=size(xom);
% yahoo = load([DIR, '/YHOO.dat']); 	[n13,fo]=size(yahoo);
% honda = load([DIR, '/HMC.dat']); 	[n14,fo]=size(honda);


%stock1 = 'TM';		stock1_name = 'TOYOTA';
%stock2 = 'XOM';		stock2_name = 'EXXON';

 stock1 = 'AMZN';	stock1_name = 'AMAZON';
 stock2 = 'GOOGL';	stock2_name = 'GOOGLE';

% stock1 = 'IBM';	stock1_name = 'IBM';
% stock2 = 'MSFT';	stock2_name = 'MICROSOFT';

    duration = 1000;	% size of sub-ensemble


x1 = load([DIR, '/', stock1, '.dat']);
x2 = load([DIR, '/', stock2, '.dat']);

% c: column
% c=1: adjusted closing price
% c=2: price increment
% c=3: (percentage) return
% c=4: log return
%
% data are ordered from most recent to oldest
%

c = 4;

[n1,fo] = size(x1);
[n2,fo] = size(x2);
nm = min(n1, n2);

% load year_month_date.dat
% [n_yr,one] = size(year_month_date);
% 
% 
% 
% 
% % X = [msft(n9-nm+1:n9,c), aapl(n1-nm+1:n1,c), ibm(n7-nm+1:n7,c), intc(n8-nm+1:n8,c), ge(n5-nm+1:n5,c), wmt(n11-nm+1:n11,c), xom(n12-nm+1:n12,c), cvs(n3-nm+1:n3,c), toyota(n10-nm+1:n10,c)];
% 
% 
% 	 yr = year_month_date(n_yr-nm+1 : n_yr, 1);
% 	 mon = year_month_date(n_yr-nm+1 : n_yr, 2);
% 	 date = year_month_date(n_yr-nm+1 : n_yr, 3);
% 	%
% 	%% the year-month-date for the series x1 & x2
% 	yr(1)
% 	mon(1)
% 	date(1)
% 	

	xx1 = x1(n1-nm+1 : n1, c);
	xx2 = x2(n2-nm+1 : n2, c);	% ensure that they are of equal length
	clear x1
	clear x2
	

    d2 = duration/2;

for n = 1+d2 : nm-d2,
	x1 = xx1(n-d2 : n+d2, 1);
	x2 = xx2(n-d2 : n+d2, 1);
[T12(n-d2,1), Terr90_12(n-d2,1), Terr95, Terr99] = causality_est(x2, x1, 1);
[T21(n-d2,1), Terr90_21(n-d2,1), Terr95, Terr99] = causality_est(x1, x2, 1);

[tau12(n-d2,1), dH_star, dH_noise] = tau_est(x2,x1,1);
[tau21(n-d2,1), dH_star, dH_noise] = tau_est(x1,x2,1);

rho = corrcoef(x1,x2);
r(n-d2,1) = rho(1,2);
end


% 	% the year-month-date for the shortened series T12 & T21
%         clear yr
%         clear mon
%         clear date
% 	yr = year_month_date(n_yr-nm+d2+1 : n_yr, 1);
% 	mon = year_month_date(n_yr-nm+d2+1 : n_yr, 2);
% 	date = year_month_date(n_yr-nm+d2+1 : n_yr, 3);
% 
% 	yr0 = yr(1) + (mon(1)-1)*21.08/253;  % + (date-1);
% 					 % 253 trading days a year
% 					 % 21.0833 days a month
% 					 % date not accurate...
% 	for nn = 1 : nm-2*d2;
% 	yyrr(nn) = yr0 + (nn-1)/253;
% 	end
	
yyrr=load('../data/date_yr.dat');
yyrr=yyrr(ceil(duration/2):ceil(duration/2)+length(T12)-1);
figure(1)
clf
subplot(2,2,1)
hold on
plot(yyrr, T12, 'b-', 'LineWidth', 2); 
plot(yyrr, T12 + Terr90_12, 'b-', 'Color', [0.7 0.7 0.7]);
plot(yyrr, T12 - Terr90_12, 'b-', 'Color', [0.7 0.7 0.7]);
plot(yyrr, zeros(size(T21)), 'b--');
% xlabel('Year')
title(['(a)  T: ', stock1_name, '\rightarrow', stock2_name]);
axis tight

% xtic = get(gca, 'XTick');
% set(gca, 'XTickLabel', yr(xtic+1));
set(gca, 'Box', 'on', 'XTickLabel', '')

subplot(2,2,3)
hold on
plot(yyrr, T21, 'b-', 'LineWidth', 2); 
plot(yyrr, T21 + Terr90_21, 'b-', 'Color', [0.7 0.7 0.7]);
plot(yyrr, T21 - Terr90_21, 'b-', 'Color', [0.7 0.7 0.7]);
plot(yyrr, zeros(size(T21)), 'b--');
xlabel('Year')
title(['(b)  T: ', stock2_name, '\rightarrow', stock1_name]);
axis tight
set(gca, 'Box', 'on')

print('-depsc', ['T_', stock1, '_', stock2, '.eps']);


% figure(2)
% clf
subplot(2,2,2)
hold on
plot(yyrr, abs(tau12)*100, 'b-', 'LineWidth', 2, 'Color', [0.7 0.7 0.7]); 
plot(yyrr, abs(tau21)*100, 'b-'); 
plot(yyrr, zeros(size(tau21)), 'r:');
% xlabel('Year')
title(['(c) |\tau| (%): ', stock1, '\rightarrow',...
	stock2, ' (thick grey);  ', stock2, '\rightarrow', stock1, ' (thin)'])
set(gca, 'Box', 'on', 'XTickLabel', '')
axis tight

subplot(2,2,4)
plot(yyrr, r)
xlabel('Year')
title(['(d) Corr. Coef. between ', stock1, ' & ', stock2])
set(gca, 'Box', 'on')
axis tight

print('-depsc', ['tau_', stock1, '_', stock2, '.eps']);
