% Example of using multi_causality_est.m
% function [T21, err90, err95, err99] = multi_causality_est(x, np)
% Estimate T21, the information transfer from series X2 to series X1, among
% M time series (stored as column vectors in X).
% dt is taken to be 1.
%
% On input:
%    XX: matrix storing the M time series (each as Nx1 column vectors)
%       X1 and X2 stored as the first two column vectors
%    np: integer >=1, time advance in performing Euler forward 
%	 differencing, e.g., 1, 2. Unless the series are generated
%	 with a highly chaotic deterministic system, np=1 should be
%	 used. 
%
% On output:
%    T21:  info flow from X2 to X1	(Note: Not X1 -> X2!)
%    err90: standard error at 90% significance level
%    err95: standard error at 95% significance level
%    err99: standard error at 99% significance level
%
%
%
% function [T21, err90, err95, err99] = multi_causality_est_all(x, np)
% On output:
%    T21:  info flow from X1(nan),X2,...,Xn to X1	
%    err90: standard error at 90% significance level
%    err95: standard error at 95% significance level
%    err99: standard error at 99% significance level
%
%
%function [T21, err90, err95, err99] = multi_causality_est_all_panel(xx, t)
% Estimate T21, the information transfer from series X2-XM to series X1, among
% M discrete time series (stored as column vectors in X).
% dt is taken to be 1.
%
% On input:
%    xx: matrix storing the M time series (each as Nx1 column vectors)
%       X1 and X2 stored as the first two column vectors
%    t: the discreted time series / unit time
%       or the time steps of the corss section
%	 e.g., 1, 2. Unless the series are generated
%	 with a highly chaotic deterministic system, np=1 should be
%	 used. 
% Citations: 
% [1] X.S. Liang, 2014: Unraveling the cause-effect relation between time
%     series. Phys. Rev. E 90, 052150.
% [2] X.S. Liang, 2015: Normalizing the causality between time series.
%     Phys. Rev. E 92, 022126.
% [3] X.S. Liang, 2016: Information flow and causality as rigorous notions
%     ab initio. Phys. Rev. E 94, 052201.
% [4] X. San Liang, 2021: Normalized Multivariate Time Series Causality 
%     Analysis and Causal Graph Reconstruction. Entropy. 23. 679.
clear

x1(1)=0.4;x2(1)=0.5;x3(1)=0.6;x4(1)=0.7;
for i=1:1000
    x1(i+1)=0.30 * x1(i) + 0.00 * x2(i)+0.00 * x3(i) + 0.00 * x4(i) + 0.40*randn(1);
    x2(i+1)=0.80 * x1(i) + 0.90 * x2(i)+0.00 * x3(i) + 0.00 * x4(i) + 0.50*randn(1);
    x3(i+1)=0.00 * x1(i) + 0.50 * x2(i)+0.50 * x3(i) + 0.00 * x4(i) + 0.60*randn(1);
    x4(i+1)=0.20 * x1(i) + 0.40 * x2(i)+0.30 * x3(i) + 0.00 * x4(i) + 0.30*randn(1);
end

xx=[x1' x2' x3' x4'];
%[T21, err90, err95, err99] = multi_causality_est(xx, 1)
key=1:4;
for i=1:4
    for j=1:4
        if i~=j
            tmp1=xx(:,i);tmp2=xx(:,j);tmp3=xx(:,key~=i&key~=j);
            %tmp1=xM(2:end,i);tmp2=xM(2:end,j);tmp3=xM(2:end,key~=i&key~=j);tmp4=xM(1:end-1,key~=i&key~=j);
            X=[tmp1,tmp2,tmp3];%,tmp4];
            [t21(i,j),~,~,err(i,j)]=multi_causality_est(X,1);
            disp([i j])
        else
            t21(i,j)=NaN;err(i,j)=NaN;
        end
    end
end    
% t21=t21;err=err;
T21=t21;
for i=1:4
    for j=1:4
        if abs(t21(i,j))<err(i,j)
            T21(i,j)=NaN;
        end
    end
end
disp(T21)

    for i=1:4
        tmp1=xx(:,i);tmp2=xx(:,key~=i);
        X=[tmp1,tmp2];%,tmp4];
        [t21(i,:),~,~,err(i,:)]=multi_causality_est_all(X,1);
        if i~=1
            tmp1=t21(i,1+find(key<i));tmp2=t21(i,1);tmp3=t21(i,find(key>i));t21(i,:)=[tmp1,tmp2,tmp3];
            tmp1=err(i,1+find(key<i));tmp2=err(i,1);tmp3=err(i,find(key>i));err(i,:)=[tmp1,tmp2,tmp3];
        end
    %     t21(i,i)=NaN;%err(i,i)=NaN;
    end    

T21=t21;
for i=1:4
    for j=1:4
        if abs(t21(i,j))<err(i,j)
            T21(i,j)=NaN;
        end
    end
end
disp(T21)

[t21,~,~,err99]=multi_causality_est_all_new(xx,1,1);
disp(t21)
disp(err99)

[t21,~,~,err]=causality_est(xx(:,1),xx(:,2),1);
disp([t21 err])
[t21,~,~,err]=multi_causality_est(xx(:,1:2),1);
disp([t21 err])
[t21,~,~,err]=multi_causality_est_all(xx(:,1:2),1);
disp([t21(2) err(2)])
[t21,~,~,err]=multi_causality_est_all_panel(xx(:,1:2),1:size(xx,1));
disp([t21(2) err(2)])
[t21,~,~,err]=multi_causality_est_all_panel(xx(:,1:2),1:size(xx,1));
disp([t21(2) err(2)])
[t21,~,~,err]=multi_causality_est_all_panel(xx(:,1:3),1:size(xx,1));
disp([t21(2) err(2)])
[t21,~,~,err]=multi_causality_est_all_panel(xx(:,1:4),1:size(xx,1));
disp([t21(2) err(2)])