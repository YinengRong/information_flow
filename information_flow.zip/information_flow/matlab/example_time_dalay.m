% time dalay

N = 500;	% time steps
b = 1;		% amplitude of stochastic perturbation

for k=1:7, x(1,k) = randn; end


for n = 2 : N,
    x(n,1) = 0.95 * sqrt(2) * x(n-1,1) - 0.9025 * x(n-1,6) + b*randn;
    x(n,2) = 0.5*x(n-1,6) + b*randn;
    x(n,3) = -0.4*x(n-1,7) + b*randn;
    x(n,4) = -0.5*x(n-1,6) + 0.25*sqrt(2) * (x(n-1,4) + x(n-1,5)) + b*randn;
    x(n,5) = 0.25*sqrt(2) * (-x(n-1,4) + x(n-1,5)) + b*randn;
    x(n,6) = x(n-1,1);
    x(n,7) = x(n-1,6);
end

for i = 1 : 7,
for j = 1 : 7,
	if i~=j, 
	   indx=[]; 
	   for k=1:7,
	   	if k~=i & k~=j, indx = [indx, k]; end
     	   end
	xy = [x(:,i) x(:,j) x(:,indx)];
	[T(j,i), err90(j,i), err95(j,i), err99(j,i)] = ...
					multi_causality_est(xy, 1);
	else
	T(j,i) = 0;
	end
end
end

ind=abs(T)>err99&abs(T)>0.0001;
disp(ind)
T(~ind)=nan;
disp(T)




