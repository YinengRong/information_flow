function [T21, err90, err95, err99] = time_varying_causality(x1, x2, win, np)
% 
% function [T21, err90, err95, err99] = time_varying_causality(x1, x2, win, np)
%
% Estimate the time-varying causality from X2 to X12, T21(t), and its
% time-varying standard error (resp. at a 90%, 95%, 99% confidence level).
%
% Time stepsize dt is taken to be 1 (i.e., final result should be divided
% by dt).
%
% T21(t) is estimated from interval [t-win/2, t+win/2].
%
%
% On input:
%    X1, X2: the series (N x 1 column vectors)
%    WIN: time window size (must <= N);  
%	  T21(t) is estimated on interval  [t-win/2, t+win/2]
%    np: integer >=1, time advance in performing Euler forward 
%	 differencing, e.g., 1, 2. Unless the series are generated
%	 with a highly chaotic deterministic system, np=1 should be
%	 used. 
%
% On output:
%    T21:  info flow from X2 to X1	(Note: Not X1 -> X2!)
%    err90: standard error at 90% confidence level
%    err95: standard error at 95% confidence level
%    err99: standard error at 99% confidence level
%
% Note: All the outputs are of Nx1 column vectors corresponding to the 
% original series. Since there are no values before t=win/2 and after
% t=N-win/2, those points are padded with zeros (they should be discarded).
%
% Citations: 
%    X. San Liang, 2014: Unraveling the cause-effect relation between time series. Phys. Rev. E 90, 052150.
%    X. San Liang, 2015: Normalizing the causality between time series. Phys. Rev. E 92, 022126.
%
% Dependencies:
%    causality_est.m
%
   
[nm, one] = size(x1);
T21 = zeros(nm,1);
err90 = zeros(nm,1);
err95 = zeros(nm,1);
err99 = zeros(nm,1);

   if one~=1, 
   fprintf('Error: time series must be in column vector form.\n'); return;
   end
[nm1, one] = size(x2);
   if nm1~=nm, 
   fprintf('Error: time series must be of the same length.\n'); return;
   end

   if win > nm,
   fprintf('Error: time window size (win) must be less than N.\n'); return;
   end


win2 = floor(win/2);

for t = 1+win2  :  nm-win2,
    xx1 = x1(t-win2 : t+win2, 1);
    xx2 = x2(t-win2 : t+win2, 1);
[T21(t,1), err90(t,1), err95(t,1), err99(t,1)] = causality_est(xx1, xx2, np);
end


