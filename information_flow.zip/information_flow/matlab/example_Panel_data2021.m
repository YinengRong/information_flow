X=load('../data/X.dat');
time=load('../data/time.dat');
%X1 Energy consumption;X2 Economic growth;X3 Trade openness;X4 Oil price
%原始数据 (部分时刻有缺测，dat文件中已剔除) ：
%BP Statistical Review of World Energy June 2013
%PWT.country：https://www.rug.nl/ggdc/productivity/pwt/pwt-releases/pwt8.0?lang=en
%World Development Indicators (2013) of the World Bank
% 31  China                                 
% 66  Hong Kong                             
% 71  India                                 
% 13  Bangladesh                            
% 92  SriLanka                              
% 124 Philippines                           
% 148 Thailand                              
% 70  Indonesia                             
% 112 Malaysia                              
% 80  Japan                                 
% 79  Jordan                                
% 73  Iran                                  
% 86  Korea, Republic of                    
% 118 Nepal                                 
% 163 Vietnam                               
T21=ones(4)*NaN;err80=ones(4)*NaN;err80=ones(4)*NaN;err80=ones(4)*NaN;
for i=1:4
    for j=1:4
        if i~=j
            [T21(i,j), err80(i,j), err95(i,j), err99(i,j)]=causality_est_panel_80(X(i,:)', X(j,:)',time);
        end
    end
end


disp((abs(T21)>err80)+(abs(T21)>err95)+(abs(T21)>err99))
disp('1: under 80% significance')
disp('2: under 95% significance')
disp('3: under 99% significance')